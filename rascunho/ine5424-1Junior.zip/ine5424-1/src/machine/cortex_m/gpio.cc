// EPOS Cortex-M GPIO Mediator Implementation

#include <machine/ic.h>
#include <machine/gpio.h>

#ifdef __GPIO_H

__BEGIN_SYS

// Class attributes
GPIO * GPIO::_devices[GPIO_PORTS][8];
unsigned char GPIO::_mis[GPIO_PORTS];
unsigned int GPIO::_irq_detect_ack[GPIO_PORTS];

// Class methods
void GPIO::int_handler(const IC::Interrupt_Id & id)
{
    unsigned int port = id - IC::INT_GPIOA;

    unsigned int mis = _mis[port];
    _mis[port] = 0;
    unsigned int irq_detect_ack = _irq_detect_ack[port];
    _irq_detect_ack[port] = 0;

    for(unsigned int i = 0; i < 8; ++i) {
        bool regular_interrupt = mis & (1 << i);
        bool power_up_interrupt = irq_detect_ack & ((1 << i) << (8 * port));
        if(regular_interrupt || power_up_interrupt)
            _devices[port][i]->notify();
    }
}

void GPIO::eoi(const IC::Interrupt_Id & id)
{
    unsigned int port = id - IC::INT_GPIOA;
    _mis[port] |= gpio(port, MIS);
    _irq_detect_ack[port] |= gpio(port, IRQ_DETECT_ACK);

    // Clear regular interrupts even if no handler is available
    gpio(port, ICR) = -1;

    // Clear power-up interrupts even if no handler is available
    // There is something weird going on here.
    // The manual says: "There is a self-clearing function to this register that generates a
    // reset pulse to clear any interrupt which has its corresponding bit set to 1."
    // But this is not happening!
    // Also, clearing only the bit that is set or replacing the statement below with
    // regs[irq_number](IRQ_DETECT_ACK) = 0;
    // do not work!
    gpio(port, IRQ_DETECT_ACK) &= -1;
}

void GPIO::int_enable(const Edge & edge, bool power_up, const Edge & power_up_edge)
{
    IC::Interrupt_Id int_id = IC::INT_GPIOA + _port;
    IC::disable(int_id);
    int_disable();
    IC::int_vector(int_id, int_handler);

    gpio(_port, IS) &= ~_pin_bit; // Set interrupt to edge-triggered

    switch(edge) {
    case NONE:
        break;
    case RISING:
        gpio(_port, IBE) &= ~_pin_bit; // Interrupt on single edge, defined by IEV
        gpio(_port, IEV) |= _pin_bit;
        break;
    case FALLING:
        gpio(_port, IBE) &= ~_pin_bit; // Interrupt on single edge, defined by IEV
        gpio(_port, IEV) &= ~_pin_bit;
        break;
    case BOTH:
        gpio(_port, IBE) |= _pin_bit;
        break;
    }

    clear_interrupt();
    int_enable();

    if(supports_power_up && power_up) {
        assert(power_up_edge != BOTH);
        if (power_up_edge == FALLING)
            gpio(_port, P_EDGE_CTRL) |= (_pin_bit << (8 * _port));
        else if (power_up_edge == RISING)
            gpio(_port, P_EDGE_CTRL) &= ~(_pin_bit << (8 * _port));
        gpio(_port, PI_IEN) |= (_pin_bit << (8 * _port));
    }

    IC::enable(int_id);
}

__END_SYS

#endif
