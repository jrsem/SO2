// EPOS-- ARMv7 MMU Mediator Implementation

#include <architecture/armv7/mmu.h>

__BEGIN_SYS

// Class attributes
MMU::List MMU::_free;

__END_SYS
