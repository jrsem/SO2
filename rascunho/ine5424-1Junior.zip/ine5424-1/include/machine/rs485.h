// EPOS RS485 Mediator Common Package

#ifndef __RS485_h
#define __RS485_h

#include <system/config.h>

#ifdef __RS485_H
#include __RS485_H
#endif

#endif
